# SIAE Mobile-First Design System

Vue 3 + TypeScript + Vite library with Tailwind v4. Includes a small playground and unit tests.

## Scripts

- `dev`: run playground
- `build`: build library (ES + UMD) and types
- `preview`: preview built playground
- `test:unit`: run Vitest
- `lint`: run linters

## Usage (as a library)

Install and import components:

```ts
import { DsButton } from '@itsiae/siae-design-system';
import 'siae-design-system/dist/style.css';
```

This design system includes Nuxt UI styles and components as a peer dependency (`@nuxt/ui`). If you use the playground or want to use Nuxt UI components alongside our DS components in a non-Nuxt Vite app, ensure the Vite plugin is enabled and styles are imported (already wired here):

```ts
// vite.config.ts
import ui from '@nuxt/ui/vite';
export default defineConfig({ plugins: [vue(), ui()] });
```

## Local development

```bash
pnpm i
pnpm dev
```
